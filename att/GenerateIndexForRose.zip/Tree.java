/*This code was generated using the UMPLE 1.20.1.4304 modeling language!*/
//class Tree {
//	  name;
//	  content;
//	  image;
//	  foldername;
//	  htmname;
//	  0..1 parent -- * Tree trees;
//	}

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// line 2 "model.ump"
public class Tree
{

	//------------------------
	// MEMBER VARIABLES
	//------------------------

	//Tree Attributes
	private String name;
	private String content;
	private String image;
	private String foldername;
	private String htmname;

	//Tree Associations
	private List<Tree> trees;
	private Tree parent;

	//------------------------
	// CONSTRUCTOR
	//------------------------

	public Tree(String aName, String aContent, String aImage, String aFoldername, String aHtmname)
	{
		name = aName;
		content = aContent;
		image = aImage;
		foldername = aFoldername;
		htmname = aHtmname;
		trees = new ArrayList<Tree>();
	}

	//------------------------
	// INTERFACE
	//------------------------

	public Tree() {
		// TODO Auto-generated constructor stub
	}

	public boolean setName(String aName)
	{
		boolean wasSet = false;
		name = aName;
		wasSet = true;
		return wasSet;
	}

	public boolean setContent(String aContent)
	{
		boolean wasSet = false;
		content = aContent;
		wasSet = true;
		return wasSet;
	}

	public boolean setImage(String aImage)
	{
		boolean wasSet = false;
		image = aImage;
		wasSet = true;
		return wasSet;
	}

	public boolean setFoldername(String aFoldername)
	{
		boolean wasSet = false;
		foldername = aFoldername;
		wasSet = true;
		return wasSet;
	}

	public boolean setHtmname(String aHtmname)
	{
		boolean wasSet = false;
		htmname = aHtmname;
		wasSet = true;
		return wasSet;
	}

	public String getName()
	{
		return name;
	}

	public String getContent()
	{
		return content;
	}

	public String getImage()
	{
		return image;
	}

	public String getFoldername()
	{
		return foldername;
	}

	public String getHtmname()
	{
		return htmname;
	}

	public Tree getTree(int index)
	{
		Tree aTree = trees.get(index);
		return aTree;
	}

	public List<Tree> getTrees()
	{
		List<Tree> newTrees = Collections.unmodifiableList(trees);
		return newTrees;
	}

	public int numberOfTrees()
	{
		int number = trees.size();
		return number;
	}

	public boolean hasTrees()
	{
		boolean has = trees.size() > 0;
		return has;
	}

	public int indexOfTree(Tree aTree)
	{
		int index = trees.indexOf(aTree);
		return index;
	}

	public Tree getParent()
	{
		return parent;
	}

	public boolean hasParent()
	{
		boolean has = parent != null;
		return has;
	}

	public static int minimumNumberOfTrees()
	{
		return 0;
	}

	public boolean addTree(Tree aTree)
	{
		boolean wasAdded = false;
		if (trees.contains(aTree)) { return false; }
		Tree existingParent = aTree.getParent();
		if (existingParent == null)
		{
			aTree.setParent(this);
		}
		else if (!this.equals(existingParent))
		{
			existingParent.removeTree(aTree);
			addTree(aTree);
		}
		else
		{
			trees.add(aTree);
		}
		wasAdded = true;
		return wasAdded;
	}

	public boolean removeTree(Tree aTree)
	{
		boolean wasRemoved = false;
		if (trees.contains(aTree))
		{
			trees.remove(aTree);
			aTree.setParent(null);
			wasRemoved = true;
		}
		return wasRemoved;
	}

	public boolean addTreeAt(Tree aTree, int index)
	{  
		boolean wasAdded = false;
		if(addTree(aTree))
		{
			if(index < 0 ) { index = 0; }
			if(index > numberOfTrees()) { index = numberOfTrees() - 1; }
			trees.remove(aTree);
			trees.add(index, aTree);
			wasAdded = true;
		}
		return wasAdded;
	}

	public boolean addOrMoveTreeAt(Tree aTree, int index)
	{
		boolean wasAdded = false;
		if(trees.contains(aTree))
		{
			if(index < 0 ) { index = 0; }
			if(index > numberOfTrees()) { index = numberOfTrees() - 1; }
			trees.remove(aTree);
			trees.add(index, aTree);
			wasAdded = true;
		} 
		else 
		{
			wasAdded = addTreeAt(aTree, index);
		}
		return wasAdded;
	}

	public boolean setParent(Tree aParent)
	{
		boolean wasSet = false;
		Tree existingParent = parent;
		parent = aParent;
		if (existingParent != null && !existingParent.equals(aParent))
		{
			existingParent.removeTree(this);
		}
		if (aParent != null)
		{
			aParent.addTree(this);
		}
		wasSet = true;
		return wasSet;
	}

	public void delete()
	{
		while( !trees.isEmpty() )
		{
			trees.get(0).setParent(null);
		}
		if (parent != null)
		{
			Tree placeholderParent = parent;
			this.parent = null;
			placeholderParent.removeTree(this);
		}
	}


	public String toString()
	{
		String outputString = "";
		for (int i=0; i<this.getTrees().size(); i++)
			outputString = outputString + "\n SubTree " + i + ":" + this.getTree(i).toString();
		return super.toString() + "["+
				"name" + ":" + getName()+ "," +
						"content" + ":" + getContent()+ "," +
								"image" + ":" + getImage()+ "," +
										"foldername" + ":" + getFoldername()+ "," +
												"htmname" + ":" + getHtmname()+ "]"
												+ outputString;
	}
}