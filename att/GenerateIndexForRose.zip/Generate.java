import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

class Generate {

	public static void main(String[] args) {
		if(args.length != 1)
		{
			System.out.println("Proper usage is: java program filename");
			System.exit(0);
		}

		Tree root = new Tree("Dummy", "", "webviewer/16.jpg", "", ""); // Useful if more than one Rose view.
		String html="";

		createTree(args[0], 0, root);

		root = root.getTree(0); // Skip dummy level.
		root.setName("Metamodel"); // Rename Logical View

		html="<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
		html=html+"<html>\n<head>\n   <meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">\n";
		html=html+"   <title>Metamodel Description</title>\n   <base target=\"contents_frame\">\n</head>\n<body>\n<ul style=\"list-style: none; padding-left: 1em;\">\n";
		html=html+generateHTML(0, root); // insert enumeration
		html=html+"</ul>\n</body>\n</html>\n";

		System.out.println(html);

	}


	// Recursively embed tree nodes in HTML code
	private static String generateHTML(int level, Tree tree) {
		String html="";
		int size = tree.getTrees().size();

		// Indentation according to level
		String spacing = "   ";
		for (int i=0; i<level; i++)
			spacing = spacing + "   ";

		html=html+spacing+"<li><img src=\"" + tree.getImage() + "\" border=0> <a href=\"";
		if (tree.getParent()!=null)
			html=html+tree.getParent().getFoldername();
		html=html+ tree.getHtmname() + "\">" + tree.getName() + "</a>\n";

		if (size > 0)
		{
			html=html+spacing+"<ul style=\"list-style: none; padding-left: 1em;\">\n";

			for (int i=0; i<size; i++)
			{
				if (tree.getTree(i).getImage() !=null)
					if ( (tree.getTree(i).getImage().equals("webviewer/16.jpg")) || (tree.getTree(i).getImage().equals("webviewer/18.jpg")) )
						// Keep only folders and diagrams
						html=html+generateHTML(level+1, tree.getTree(i));
			}

			html=html+spacing+"</ul>\n";
		}

		return html;
	}

	// Recursively create tree while flattening the structure
	private static void createTree(String filename, int level, Tree parent)
	{
		List<String> lines;
		String line;
		String name=null;
		String content=null;
		String image=null;
		String foldername="";
		String htmname=null;

		// Assume Windows paths...
		String path=filename.substring(0,filename.lastIndexOf('\\')+1);

		// Indentation according to level
		String spacing = new String();
		for (int i=0; i<level; i++)
			spacing = spacing + "   ";

		lines = readFile(filename);

		for (int i=(level==0?1:0); i<lines.size(); i++) {
			line = lines.get(i);

			if (line.length()>3)
			{
				if (line.endsWith(".htm"))
					htmname = line;
				else if (line.endsWith(".cnt"))
					content=path+line.replace('/', '\\');
				else if (line.endsWith(".jpg") || line.endsWith(".gif"))
					image = line.substring(line.indexOf('w')); // Always from the root webviewer image folder
				else if (line.endsWith("/"))
					foldername=parent.getFoldername() + line;
				else 
				{
					if (name!=null)
					{
						Tree tree = new Tree(name, content, image, foldername, htmname);
						parent.addTree(tree);
						if (content !=null)
							createTree(content, level+1, tree);
						// Prepare for next...
						name=line;
						content=null;
						image=null;
						foldername="";
						htmname=null;						
					}
					else 
						name = line;
				}
			}
			else
			{
				if (line.length()>1)
				{
					if (name!=null)
					{
						Tree tree = new Tree(name, content, image, foldername, htmname);
						parent.addTree(tree);
						if (content !=null)
							createTree(content, level+1, tree);
						// Prepare for next...
						name=line;
						content=null;
						image=null;
						foldername="";
						htmname=null;						
					}
					else 
						name = line;
				}
				else
					; // skip
			}
		}

		// Last one...
		Tree tree = new Tree(name, content, image, foldername, htmname);
		parent.addTree(tree);
		if (content !=null)
			createTree(content, level+1, tree);
	}

	/**
	 * Open and read a file, and return the lines in the file as a list
	 * of Strings.
	 * (Demonstrates Java FileReader, BufferedReader, and Java5.)
	 */
	private static List<String> readFile(String filename)
	{
		List<String> records = new ArrayList<String>();
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			String line;
			while ((line = reader.readLine()) != null)
			{
				records.add(line);
			}
			reader.close();
			return records;
		}
		catch (Exception e)
		{
			System.err.format("Exception occurred trying to read '%s'.", filename);
			e.printStackTrace();
			return null;
		}
	}
}
