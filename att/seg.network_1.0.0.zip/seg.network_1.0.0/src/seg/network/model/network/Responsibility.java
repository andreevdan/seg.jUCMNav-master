/**
 * <copyright>
 * </copyright>
 *
 * $Id: Responsibility.java,v 1.2 2005/02/15 19:35:39 etremblay Exp $
 */
package seg.network.model.network;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Responsibility</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see seg.network.model.network.NetworkPackage#getResponsibility()
 * @model 
 * @generated
 */
public interface Responsibility extends Node {
} // Responsibility
