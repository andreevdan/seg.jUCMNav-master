/**
 * <copyright>
 * </copyright>
 *
 * $Id: StartPoint.java,v 1.3 2005/02/15 19:35:40 etremblay Exp $
 */
package seg.network.model.network;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Start Point</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see seg.network.model.network.NetworkPackage#getStartPoint()
 * @model 
 * @generated
 */
public interface StartPoint extends Node {
} // StartPoint
