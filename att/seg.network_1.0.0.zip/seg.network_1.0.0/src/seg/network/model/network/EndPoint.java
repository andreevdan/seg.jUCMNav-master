/**
 * <copyright>
 * </copyright>
 *
 * $Id: EndPoint.java,v 1.3 2005/02/15 19:35:39 etremblay Exp $
 */
package seg.network.model.network;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>End Point</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see seg.network.model.network.NetworkPackage#getEndPoint()
 * @model 
 * @generated
 */
public interface EndPoint extends Node {
} // EndPoint
